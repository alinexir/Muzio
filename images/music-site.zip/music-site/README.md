# راهنمای راه‌اندازی (سایت موزیک مجاز)

## ۱–۳. GitHub و GitHub Pages
1. در github.com یک Repository بسازید (مثلاً `music-site`).
2. همه فایل‌ها را آپلود کنید (Add file → Upload files).
3. Settings → Pages → Source: `main` / root → Save. سایت روی `username.github.io/music-site` بالا می‌آید.

## ۴. Cloudflare Worker (برای API و پنل)
1. dash.cloudflare.com → Workers & Pages → Create → Worker؛ کد `worker/worker.js` را جایگذاری و Deploy کنید.
2. Storage → KV → یک Namespace بسازید و در Worker → Settings → Bindings با نام `KV` وصل کنید.
3. Variables → `DATA_URL` = آدرس کامل `data/songs.json` روی GitHub Pages.

## ۵–۶. دامنه و DNS
دامنه را به Cloudflare اضافه کنید (تغییر Nameserver). در DNS یک رکورد `CNAME` به `username.github.io` (Proxied) بسازید و در تنظیمات Pages همان دامنه را بدهید. برای Worker: Settings → Domains & Routes → `api.example.com`.

## ۷. Secrets
Worker → Settings → Variables → Add → نوع **Secret** با نام `ADMIN_TOKEN` و یک رمز طولانی. هرگز آن را در GitHub نگذارید.

## ۸. Import Manager
`API` در `js/admin.js` و `API_BASE` در `js/app.js` را به آدرس Worker تغییر دهید. به `/admin/` بروید، توکن را وارد کنید، URL یک API/RSS **مجاز** بدهید، Preview ببینید و منتشر کنید. منبع جدید = افزودن یک تابع به `IMPORTERS` در Worker.

## ۹. اولین آهنگ
در `/admin/` فرم افزودن را پر کنید (فقط لینک صوتی‌ای که حق انتشارش را دارید). بعداً برای فایل‌ها می‌توانید Cloudflare R2 اضافه کنید.

## ۱۰. تست موبایل
سایت را روی گوشی باز کنید؛ پلیر پایین صفحه با دکمه ⌃ جمع می‌شود. روی دسکتاپ: DevTools → Device toolbar.

## نکته SEO
متاتگ‌ها و JSON-LD هر آهنگ با جاوااسکریپت ساخته می‌شوند. برای ایندکس بهتر، بعداً صفحات ایستای `/song/slug` تولید کنید.
